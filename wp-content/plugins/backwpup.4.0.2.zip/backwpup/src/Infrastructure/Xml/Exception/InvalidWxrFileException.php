<?php

declare(strict_types=1);

namespace Inpsyde\BackWPup\Infrastructure\Xml\Exception;

final class InvalidWxrFileException extends \RuntimeException
{
}
