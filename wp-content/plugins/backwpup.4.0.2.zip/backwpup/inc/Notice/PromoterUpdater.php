<?php

// -*- coding: utf-8 -*-

namespace Inpsyde\BackWPup\Notice;

class PromoterUpdater
{
    public function update()
    {
    }
}
