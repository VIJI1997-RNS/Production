<?php

// -*- coding: utf-8 -*-

namespace Inpsyde\BackWPup\Notice;

class Promoter
{
    public const OPTION_NAME = 'backwpup_notice_promoter';
}
